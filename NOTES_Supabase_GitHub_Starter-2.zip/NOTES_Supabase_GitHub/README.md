# NOTES — Supabase + GitHub starter

## What this starter does
- Supabase email/password sign-up and login
- Real email confirmation through Supabase Auth when confirmations and email delivery are configured
- Persistent sessions until logout
- Shared notes feed, search, optional image URL, delete-own-post
- Basic profile and Instagram/YouTube links
- Community member list
- Responsive navigation for Home, Chat, Games, Social, Profile

**Chat and multiplayer games are placeholders, not working features yet.** Images are added by URL; uploading image files requires configuring Supabase Storage.

## Setup
1. In Supabase, open **SQL Editor → New query**, paste `schema.sql`, and run it.
2. In **Authentication → Sign In / Providers → Email**, enable sign-ups and email confirmations.
3. Configure SMTP under **Authentication → SMTP Settings** for reliable delivery to real users.
4. Open **Project Settings → API** and copy the Project URL plus the publishable key (or legacy anon/public key).
5. Edit `index.html`; replace `YOUR_SUPABASE_PROJECT_URL` and `YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY`.
6. Test locally with a static server such as `npx serve .`. Add the exact local URL to Supabase **Authentication → URL Configuration → Redirect URLs**.
7. To publish: create a GitHub repository, upload `index.html`, `schema.sql`, and `README.md`. In repository **Settings → Pages**, select deploy from branch `main`, folder `/ (root)`.
8. Add your public GitHub Pages URL to Supabase Redirect URLs and set it as Site URL. Test signup and email confirmation.

## Security
Never put a service-role/secret key, database password, or SMTP password in the HTML or GitHub. Browser code may use the publishable/anon key only when Row Level Security is enabled. Keep the policies in `schema.sql`.

## Community model
Everyone who registers and verifies their email is automatically part of the same NOTES circle. There are no follow requests. This is not invite-only: anyone can register unless you add a server-side invite-code or approved-user rule.
